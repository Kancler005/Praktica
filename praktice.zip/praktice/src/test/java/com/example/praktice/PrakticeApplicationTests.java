package com.example.praktice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrakticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
