package com.example.praktice.controllers;

import com.example.praktice.models.AppConfig;
import com.example.praktice.repositories.AppConfigRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class MonitoringController {

    @Autowired
    private AppConfigRepository appConfigRepository;

    @GetMapping("/api/monitoring/status")
    public List<AppConfig> getServiceStatus() {
        return appConfigRepository.findAll();
    }
}
