package com.example.praktice.repositories;

import com.example.praktice.models.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
    // не знаю как правильно добавить доп методы
}
